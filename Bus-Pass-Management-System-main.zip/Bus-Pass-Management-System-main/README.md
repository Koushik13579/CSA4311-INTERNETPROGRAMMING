"#Bus-Pass-Management-System"

This project will help student to get Online pass through out this Web Portal also help staff to manage data over internet. This project also delivers efficient service to student to register to student pass and pay bus fee online using this portal. Our web application to main pages i.e. Student and Admin. In that we tried to provide separate account for each and every student in college. Every student can create their account on portal using  their PRN, Name, Email and individual Password. After successful log into student portal student will display their account information on main page where they can apply for new pass or they can renew their pass. For student verification we will provide separate QR-code to each and every student which will be verified by concern bus faculty.
![Admin_Login](https://user-images.githubusercontent.com/96232989/209537976-74f9158c-08b3-42e6-aee4-276616acc948.png)

![Admin Dash](https://user-images.githubusercontent.com/96232989/209537967-97c92a92-b849-44f3-93a0-1394acc81643.png)![Student_login](https://user-images.githubusercontent.com/96232989/209538014-62d66634-5a09-4327-89ad-bbb382e184ca.png)

![Student_Home](https://user-images.githubusercontent.com/96232989/209538004-a679d748-e097-4c28-9a78-8f3266a034d4.png)
![Bus Data Flow](https://user-images.githubusercontent.com/96232989/209538069-1207a276-b7d2-435b-8125-af2e7f29a6b2.png)
![Bus Use case](https://user-images.githubusercontent.com/96232989/209538081-b35e1090-d4c7-4253-a17c-dc7fe3377f9f.png)
